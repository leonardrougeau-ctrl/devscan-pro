#!/bin/bash
echo "🚀 Installing DevScan Pro v1.0.0"
echo "=================================="

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Please install python3."
    exit 1
fi

# Check Tkinter
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "📦 Tkinter not found. Installing..."
    sudo apt update && sudo apt install python3-tk -y
fi

# Install dependencies if requirements exist
if [ -f "requirements.txt" ]; then
    echo "📦 Installing Python dependencies..."
    pip3 install -r requirements.txt
fi

# Launch application
echo "🎯 Launching DevScan Pro..."
python3 devscan_pro.py
