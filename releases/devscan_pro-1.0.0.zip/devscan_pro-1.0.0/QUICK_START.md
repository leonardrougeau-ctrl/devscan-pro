# DevScan Pro - Quick Start

## Installation
1. Run: `./install.sh`
2. Or manually: `python3 devscan_pro.py`

## System Requirements
- Ubuntu 18.04+ or compatible Linux
- Python 3.6+
- Tkinter

## Support
- Email: support@devscan.pro
- Website: https://devscan.pro
