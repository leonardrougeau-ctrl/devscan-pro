#!/bin/bash
cd "$(dirname "$0")"
python3 devscan_pro.py
